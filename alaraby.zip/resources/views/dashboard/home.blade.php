@extends('layouts.dashboard.app')

@section('adminContent')
@endsection
