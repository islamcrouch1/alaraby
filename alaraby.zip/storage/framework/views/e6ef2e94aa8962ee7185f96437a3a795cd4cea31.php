<nav class="navbar navbar-light navbar-glass navbar-top navbar-expand">

    <button class="btn navbar-toggler-humburger-icon navbar-toggler me-1 me-sm-3" type="button" data-bs-toggle="collapse"
        data-bs-target="#navbarVerticalCollapse" aria-controls="navbarVerticalCollapse" aria-expanded="false"
        aria-label="Toggle Navigation"><span class="navbar-toggle-icon"><span
                class="toggle-line"></span></span></button>
    <a class="navbar-brand me-1 me-sm-3" href="<?php echo e(route('home')); ?>">
        <div class="d-flex align-items-center"><img class="me-2" src="<?php echo e(asset('assets/img/logo-blue.png')); ?>"
                alt="" width="150" />
        </div>
    </a>
    <ul class="navbar-nav align-items-center d-none d-lg-block">
        <li class="nav-item">
            <div class="search-box" data-list='{"valueNames":["title"]}'>
                <form class="position-relative" data-bs-toggle="search" data-bs-display="static">
                    <input class="form-control search-input fuzzy-search" type="search"
                        value="<?php echo e(request()->search); ?>" name="search" autofocus placeholder="Search..."
                        aria-label="Search" />
                    <span class="fas fa-search search-box-icon"></span>

                </form>
            </div>
        </li>
    </ul>
    <ul class="navbar-nav navbar-nav-icons ms-auto flex-row align-items-center">
        
        <li class="nav-item">
            <div class="theme-control-toggle fa-icon-wait px-2">
                <input class="form-check-input ms-0 theme-control-toggle-input" id="themeControlToggle" type="checkbox"
                    data-theme-control="theme" value="dark" />
                <label class="mb-0 theme-control-toggle-label theme-control-toggle-light" for="themeControlToggle"
                    data-bs-toggle="tooltip" data-bs-placement="left" title="Switch to light theme"><span
                        class="fas fa-sun fs-0"></span></label>
                <label class="mb-0 theme-control-toggle-label theme-control-toggle-dark" for="themeControlToggle"
                    data-bs-toggle="tooltip" data-bs-placement="left" title="Switch to dark theme"><span
                        class="fas fa-moon fs-0"></span></label>
            </div>
        </li>
        <?php if(Auth::user()->hasRole('affiliate')): ?>
            <li class="nav-item  d-sm-block">
                <a class="nav-link px-0 notification-indicator notification-indicator-warning notification-indicator-fill fa-icon-wait"
                    href="<?php echo e(route('cart')); ?>"><span class="fas fa-shopping-cart" data-fa-transform="shrink-7"
                        style="font-size: 33px;"></span><span
                        class="notification-indicator-number cart-count"><?php echo e(Auth::user()->cart->products->count()); ?></span></a>

            </li>
            <li class="nav-itemd-sm-block">
                <a class="nav-link px-0 notification-indicator notification-indicator-danger notification-indicator-fill fa-icon-wait"
                    href="<?php echo e(route('favorite')); ?>"><span class="fas fa-solid fa-heart" data-fa-transform="shrink-7"
                        style="font-size: 33px;"></span><span
                        class="notification-indicator-number fav-icon"><?php echo e(Auth::user()->fav->count()); ?></span></a>

            </li>
        <?php endif; ?>

        

        <li class="nav-item dropdown"><a class="nav-link pe-0 ps-2" id="navbarDropdownUser" role="button"
                data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <div class="avatar avatar-xl">
                    <img class="rounded-circle" src="<?php echo e(asset('storage/images/users/' . Auth::user()->profile)); ?>"
                        alt="" />

                </div>
            </a>
            <div class="dropdown-menu dropdown-menu-end py-0" aria-labelledby="navbarDropdownUser">
                <div class="bg-white dark__bg-1000 rounded-2 py-2">

                    
                    <a class="dropdown-item" href="<?php echo e(route('user.edit')); ?>">Profile &amp; account</a>
                    <a class="dropdown-item"
                        href="<?php echo e(route('notifications.index')); ?>"><?php echo e(__('Notifications')); ?></a>
                    <a class="dropdown-item" href="<?php echo e(route('messages.index')); ?>"><?php echo e(__('Messages')); ?></a>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>

                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'class' => 'dropdown-item','style' => 'padding-left:1rem !important; padding-left:1rem !important','onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'class' => 'dropdown-item','style' => 'padding-left:1rem !important; padding-left:1rem !important','onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']); ?>
                            <?php echo e(__('Logout')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </form>
                </div>
            </div>
        </li>
    </ul>
</nav>
<?php /**PATH D:\work\alaraby\resources\views/layouts/Dashboard/_header.blade.php ENDPATH**/ ?>