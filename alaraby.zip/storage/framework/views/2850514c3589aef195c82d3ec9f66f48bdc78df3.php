<?php $__env->startSection('adminContent'); ?>
    <div class="card mb-3" id="customersTable"
        data-list='{"valueNames":["name","email","phone","address","joined"],"page":10,"pagination":true}'>
        <div class="card-header">
            <div class="row flex-between-center">
                <div class="col-4 col-sm-auto d-flex align-items-center pe-0">
                    <h5 class="fs-0 mb-0 text-nowrap py-2 py-xl-0">
                        <?php if($comments->count() > 0 && $comments[0]->trashed()): ?>
                            <?php echo e(__('comments trash')); ?>

                        <?php else: ?>
                            <?php echo e(__('comments')); ?>

                        <?php endif; ?>
                    </h5>
                </div>
                <div class="col-8 col-sm-auto text-end ps-2">
                    <div class="d-none" id="table-customers-actions">
                        <div class="d-flex">
                            <select class="form-select form-select-sm" aria-label="Bulk actions">
                                <option selected=""><?php echo e(__('Bulk actions')); ?></option>
                                <option value="Refund"><?php echo e(__('Refund')); ?></option>
                                <option value="Delete"><?php echo e(__('Delete')); ?></option>
                                <option value="Archive"><?php echo e(__('Archive')); ?></option>
                            </select>
                            <button class="btn btn-falcon-default btn-sm ms-2" type="button"><?php echo e(__('Apply')); ?></button>
                        </div>
                    </div>
                    <div id="table-customers-replace-element">

                        <?php if(auth()->user()->hasPermission('comments-create')): ?>
                            <a href="<?php echo e(route('comments.create')); ?>" class="btn btn-falcon-default btn-sm"
                                type="button"><span class="fas fa-plus" data-fa-transform="shrink-3 down-2"></span><span
                                    class="d-none d-sm-inline-block ms-1"><?php echo e(__('New')); ?></span></a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('comments.trashed')); ?>" class="btn btn-falcon-default btn-sm" type="button"><span
                                class="fas fa-trash" data-fa-transform="shrink-3 down-2"></span><span
                                class="d-none d-sm-inline-block ms-1"><?php echo e(__('Trash')); ?></span></a>
                        <button class="btn btn-falcon-default btn-sm" type="button"><span class="fas fa-external-link-alt"
                                data-fa-transform="shrink-3 down-2"></span><span
                                class="d-none d-sm-inline-block ms-1"><?php echo e(__('Export')); ?></span></button>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive scrollbar">
                <?php if($comments->count() > 0): ?>
                    <table class="table table-sm table-striped fs--1 mb-0 overflow-hidden">
                        <thead class="bg-200 text-900">
                            <tr>
                                <th>
                                    <div class="form-check fs-0 mb-0 d-flex align-items-center">
                                        <input class="form-check-input" id="checkbox-bulk-customers-select" type="checkbox"
                                            data-bulk-select='{"body":"table-customers-body","actions":"table-customers-actions","replacedElement":"table-customers-replace-element"}' />
                                    </div>
                                </th>
                                <th class="sort pe-1 align-middle white-space-nowrap" data-sort="name"><?php echo e(__('Name')); ?>

                                </th>

                                <th class="sort pe-1 align-middle white-space-nowrap" style="min-width: 100px;"
                                    data-sort="joined"><?php echo e(__('Created at')); ?></th>
                                <?php if($comments->count() > 0 && $comments[0]->trashed()): ?>
                                    <th class="sort pe-1 align-middle white-space-nowrap" style="min-width: 100px;"
                                        data-sort="joined"><?php echo e(__('Deleted at')); ?></th>
                                <?php endif; ?>
                                <th class="align-middle no-sort"></th>
                            </tr>
                        </thead>
                        <tbody class="list" id="table-customers-body">
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="btn-reveal-trigger">
                                    <td class="align-middle py-2" style="width: 28px;">
                                        <div class="form-check fs-0 mb-0 d-flex align-items-center">
                                            <input class="form-check-input" type="checkbox" id="customer-0"
                                                data-bulk-select-row="data-bulk-select-row" />
                                        </div>
                                    </td>
                                    <td class="name align-middle white-space-nowrap py-2">
                                        <div class="d-flex d-flex align-items-center">

                                            <div class="flex-1">
                                                <h5 class="mb-0 fs--1">
                                                    <?php echo e(app()->getLocale() == 'ar' ? $comment->name_ar : $comment->name_en); ?>

                                                </h5>
                                            </div>
                                        </div>
                                    </td>

                                    <td class="joined align-middle py-2"><?php echo e($comment->created_at); ?> <br>
                                        <?php echo e(interval($comment->created_at)); ?> </td>
                                    <?php if($comment->trashed()): ?>
                                        <td class="joined align-middle py-2"><?php echo e($comment->deleted_at); ?> <br>
                                            <?php echo e(interval($comment->deleted_at)); ?> </td>
                                    <?php endif; ?>
                                    <td class="align-middle white-space-nowrap py-2 text-end">
                                        <div class="dropdown font-sans-serif position-static">
                                            <button class="btn btn-link text-600 btn-sm dropdown-toggle btn-reveal"
                                                type="button" id="customer-dropdown-0" data-bs-toggle="dropdown"
                                                data-boundary="window" aria-haspopup="true" aria-expanded="false"><span
                                                    class="fas fa-ellipsis-h fs--1"></span></button>
                                            <div class="dropdown-menu dropdown-menu-end border py-0"
                                                aria-labelledby="customer-dropdown-0">
                                                <div class="bg-white py-2">
                                                    <?php if(
                                                        $comment->trashed() &&
                                                            auth()->user()->hasPermission('comments-restore')): ?>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('comments.restore', ['comment' => $comment->id])); ?>"><?php echo e(__('Restore')); ?></a>
                                                    <?php elseif(auth()->user()->hasPermission('comments-update')): ?>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('comments.edit', ['comment' => $comment->id])); ?>"><?php echo e(__('Edit')); ?></a>
                                                    <?php endif; ?>
                                                    <?php if(auth()->user()->hasPermission('comments-delete') ||
                                                            auth()->user()->hasPermission('comments-trash')): ?>
                                                        <form method="POST"
                                                            action="<?php echo e(route('comments.destroy', ['comment' => $comment->id])); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button class="dropdown-item text-danger"
                                                                type="submit"><?php echo e($comment->trashed() ? __('Delete') : __('Trash')); ?></button>
                                                        </form>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                <?php else: ?>
                    <h3 class="p-4"><?php echo e(__('No commentsTo Show')); ?></h3>
                <?php endif; ?>
            </div>
        </div>


        <div class="card-footer d-flex align-items-center justify-content-center">
            <?php echo e($comments->appends(request()->query())->links()); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\alaraby\resources\views/dashboard/comments/index.blade.php ENDPATH**/ ?>