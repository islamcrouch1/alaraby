<?php $__env->startSection('adminContent'); ?>
    <div class="card mb-3" id="customersTable"
        data-list='{"valueNames":["name","email","phone","address","joined"],"page":10,"pagination":true}'>
        <div class="card-header">
            <div class="row flex-between-center">
                <div class="col-4 col-sm-auto d-flex align-items-center pe-0">
                    <h5 class="fs-0 mb-0 text-nowrap py-2 py-xl-0">
                        <?php if($users->count() > 0 && $users[0]->trashed()): ?>
                            <?php echo e(__('Users trash')); ?>

                        <?php else: ?>
                            <?php echo e(__('Users')); ?>

                        <?php endif; ?>
                    </h5>
                </div>
                <div class="col-8 col-sm-auto text-end ps-2">
                    <div class="d-none" id="table-customers-actions">
                        <div class="d-flex">
                            <select class="form-select form-select-sm" aria-label="Bulk actions">
                                <option selected=""><?php echo e(__('Bulk actions')); ?></option>
                                <option value="Refund"><?php echo e(__('Refund')); ?></option>
                                <option value="Delete"><?php echo e(__('Delete')); ?></option>
                                <option value="Archive"><?php echo e(__('Archive')); ?></option>
                            </select>
                            <button class="btn btn-falcon-default btn-sm ms-2" type="button"><?php echo e(__('Apply')); ?></button>
                        </div>
                    </div>
                    <div id="table-customers-replace-element">
                        <form style="display: inline-block" action="">

                            <div class="d-inline-block">
                                
                                <input type="date" id="from" name="from" class="form-control form-select-sm"
                                    value="<?php echo e(request()->from); ?>">
                            </div>

                            <div class="d-inline-block">
                                
                                <input type="date" id="to" name="to"
                                    class="form-control form-select-sm sonoo-search" value="<?php echo e(request()->to); ?>">
                            </div>

                            <div class="d-inline-block">
                                <select name="role_id" class="form-select form-select-sm sonoo-search"
                                    id="autoSizingSelect">
                                    <option value="" selected><?php echo e(__('All Roles')); ?></option>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($role->id); ?>"
                                            <?php echo e(request()->role_id == $role->id ? 'selected' : ''); ?>><?php echo e($role->name); ?>

                                            <?php echo e(app()->getLocale() == 'ar' ? $role->name_ar : $role->name_en); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="d-inline-block">
                                <select name="status" class="form-select form-select-sm sonoo-search"
                                    id="autoSizingSelect">
                                    <option value="" selected><?php echo e(__('All Status')); ?></option>
                                    <option value="active" <?php echo e(request()->status == 'active' ? 'selected' : ''); ?>>
                                        <?php echo e(__('active')); ?></option>
                                    <option value="inactive" <?php echo e(request()->status == 'inactive' ? 'selected' : ''); ?>>
                                        <?php echo e(__('inactive')); ?></option>
                                    <option value="1" <?php echo e(request()->status == '1' ? 'selected' : ''); ?>>
                                        <?php echo e(__('blocked')); ?></option>
                                </select>
                            </div>




                        </form>
                        <?php if(auth()->user()->hasPermission('users-create')): ?>
                            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-falcon-default btn-sm"
                                type="button"><span class="fas fa-plus" data-fa-transform="shrink-3 down-2"></span><span
                                    class="d-none d-sm-inline-block ms-1"><?php echo e(__('New')); ?></span></a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('users.trashed')); ?>" class="btn btn-falcon-default btn-sm" type="button"><span
                                class="fas fa-trash" data-fa-transform="shrink-3 down-2"></span><span
                                class="d-none d-sm-inline-block ms-1"><?php echo e(__('Trash')); ?></span></a>
                        <a href="<?php echo e(route('users.export', ['role_id' => request()->role_id, 'from' => request()->from, 'to' => request()->to])); ?>"
                            class="btn btn-falcon-default btn-sm" type="button"><span class="fas fa-external-link-alt"
                                data-fa-transform="shrink-3 down-2"></span><span
                                class="d-none d-sm-inline-block ms-1"><?php echo e(__('Export')); ?></span></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive scrollbar">
                <?php if($users->count() > 0): ?>
                    <table class="table table-sm table-striped fs--1 mb-0 overflow-hidden">
                        <thead class="bg-200 text-900">
                            <tr>
                                <th>
                                    <div class="form-check fs-0 mb-0 d-flex align-items-center">
                                        <input class="form-check-input" id="checkbox-bulk-customers-select" type="checkbox"
                                            data-bulk-select='{"body":"table-customers-body","actions":"table-customers-actions","replacedElement":"table-customers-replace-element"}' />
                                    </div>
                                </th>
                                <th class="sort pe-1 align-middle white-space-nowrap" data-sort="name"><?php echo e(__('Name')); ?>

                                </th>
                                <th class="sort pe-1 align-middle white-space-nowrap" data-sort="phone"><?php echo e(__('Phone')); ?>

                                </th>
                                <th class="sort pe-1 align-middle white-space-nowrap" data-sort="email">
                                    <?php echo e(__('User Type')); ?></th>
                                <th class="sort pe-1 align-middle white-space-nowrap" data-sort="email">
                                    <?php echo e(__('Status')); ?></th>
                                <th class="sort pe-1 align-middle white-space-nowrap" style="min-width: 100px;"
                                    data-sort="joined"><?php echo e(__('Joined')); ?></th>
                                <?php if($users->count() > 0 && $users[0]->trashed()): ?>
                                    <th class="sort pe-1 align-middle white-space-nowrap" style="min-width: 100px;"
                                        data-sort="joined"><?php echo e(__('Deleted at')); ?></th>
                                <?php endif; ?>
                                <th class="align-middle no-sort"></th>
                            </tr>
                        </thead>
                        <tbody class="list" id="table-customers-body">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="btn-reveal-trigger">
                                    <td class="align-middle py-2" style="width: 28px;">
                                        <div class="form-check fs-0 mb-0 d-flex align-items-center">
                                            <input class="form-check-input" type="checkbox" id="customer-0"
                                                data-bulk-select-row="data-bulk-select-row" />
                                        </div>
                                    </td>
                                    <td class="name align-middle white-space-nowrap py-2"><a
                                            href="<?php echo e(route('users.show', ['user' => $user->id])); ?>">
                                            <div class="d-flex d-flex align-items-center">
                                                <div class="avatar avatar-xl me-2">
                                                    <img class="rounded-circle"
                                                        src="<?php echo e(asset('storage/images/users/' . $user->profile)); ?>"
                                                        alt="" />
                                                </div>
                                                <div class="flex-1">
                                                    <h5 class="mb-0 fs--1"><?php echo e($user->name); ?></h5>
                                                </div>
                                            </div>
                                        </a></td>
                                    <td class="phone align-middle white-space-nowrap py-2"><a
                                            href="tel:<?php echo e($user->phone); ?>"><?php echo e($user->phone); ?></a></td>
                                    <td class="address align-middle white-space-nowrap py-2">
                                        <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div style="display: inline-block">
                                                <span class="badge badge-soft-primary"><?php echo e($role->name); ?>

                                                </span>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td class="phone align-middle white-space-nowrap py-2">

                                        <?php if(hasVerifiedPhone($user)): ?>
                                            <span class='badge badge-soft-success'><?php echo e(__('Active')); ?></span>
                                        <?php elseif(!hasVerifiedPhone($user)): ?>
                                            <span class='badge badge-soft-danger'><?php echo e(__('Inactive')); ?></span>
                                        <?php endif; ?>
                                        <?php if($user->status == 1): ?>
                                            <span class='badge badge-soft-danger'><?php echo e(__('blocked')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="joined align-middle py-2"><?php echo e($user->created_at); ?> <br>
                                        <?php echo e(interval($user->created_at)); ?> </td>
                                    <?php if($user->trashed()): ?>
                                        <td class="joined align-middle py-2"><?php echo e($user->deleted_at); ?> <br>
                                            <?php echo e(interval($user->deleted_at)); ?> </td>
                                    <?php endif; ?>
                                    <td class="align-middle white-space-nowrap py-2 text-end">
                                        <div class="dropdown font-sans-serif position-static">
                                            <button class="btn btn-link text-600 btn-sm dropdown-toggle btn-reveal"
                                                type="button" id="customer-dropdown-0" data-bs-toggle="dropdown"
                                                data-boundary="window" aria-haspopup="true" aria-expanded="false"><span
                                                    class="fas fa-ellipsis-h fs--1"></span></button>
                                            <div class="dropdown-menu dropdown-menu-end border py-0"
                                                aria-labelledby="customer-dropdown-0">
                                                <div class="bg-white py-2">
                                                    <?php if(
                                                        $user->trashed() &&
                                                            auth()->user()->hasPermission('users-restore')): ?>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('users.restore', ['user' => $user->id])); ?>"><?php echo e(__('Restore')); ?></a>
                                                    <?php elseif(auth()->user()->hasPermission('users-update')): ?>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('users.edit', ['user' => $user->id])); ?>"><?php echo e(__('Edit')); ?></a>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('users.activate', ['user' => $user->id])); ?>"><?php echo e(hasVerifiedPhone($user) ? __('Deactivate') : __('Activate')); ?></a>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('users.block', ['user' => $user->id])); ?>"><?php echo e($user->status == 0 ? __('Block') : __('Unblock')); ?></a>
                                                        <a href="" class="dropdown-item" data-bs-toggle="modal"
                                                            data-bs-target="#bonus-modal-<?php echo e($user->id); ?>"><?php echo e(__('Add bonus')); ?></a>
                                                    <?php endif; ?>
                                                    <?php if(auth()->user()->hasPermission('users-delete') ||
                                                            auth()->user()->hasPermission('users-trash')): ?>
                                                        <form method="POST"
                                                            action="<?php echo e(route('users.destroy', ['user' => $user->id])); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button class="dropdown-item text-danger"
                                                                type="submit"><?php echo e($user->trashed() ? __('Delete') : __('Trash')); ?></button>
                                                        </form>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>

                                <!-- start bonus modal for each user -->
                                <div class="modal fade" id="bonus-modal-<?php echo e($user->id); ?>" tabindex="-1"
                                    role="dialog" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered" role="document"
                                        style="max-width: 500px">
                                        <div class="modal-content position-relative">
                                            <div class="position-absolute top-0 end-0 mt-2 me-2 z-index-1">
                                                <button
                                                    class="btn-close btn btn-sm btn-circle d-flex flex-center transition-base"
                                                    data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form method="POST"
                                                action="<?php echo e(route('users.bonus', ['user' => $user->id])); ?>">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-body p-0">
                                                    <div class="rounded-top-lg py-3 ps-4 pe-6 bg-light">
                                                        <h4 class="mb-1" id="modalExampleDemoLabel">
                                                            <?php echo e(__('Add bonus') . ' - ' . $user->name); ?></h4>
                                                    </div>
                                                    <div class="p-4 pb-0">

                                                        <div class="mb-3">
                                                            <label class="form-label"
                                                                for="bonus"><?php echo e(__('Enter bonus amount')); ?></label>
                                                            <input name="bonus"
                                                                class="form-control <?php $__errorArgs = ['bonus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                value="<?php echo e(old('bonus')); ?>" type="number"
                                                                autocomplete="on" id="bonus" autofocus required />
                                                            <?php $__errorArgs = ['bonus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-secondary" type="button"
                                                        data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                                    <button class="btn btn-primary"
                                                        type="submit"><?php echo e(__('Add')); ?></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!-- end bonus modal for each user -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                <?php else: ?>
                    <h3 class="p-4"><?php echo e(__('No Users To Show')); ?></h3>
                <?php endif; ?>
            </div>
        </div>


        <div class="card-footer d-flex align-items-center justify-content-center">
            <?php echo e($users->appends(request()->query())->links()); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\alaraby\resources\views/Dashboard/users/index.blade.php ENDPATH**/ ?>