<nav class="navbar navbar-light navbar-vertical navbar-expand-xl">
    <script>
        var navbarStyle = localStorage.getItem("navbarStyle");
        if (navbarStyle && navbarStyle !== 'transparent') {
            document.querySelector('.navbar-vertical').classList.add(`navbar-${navbarStyle}`);
        }
    </script>
    <div class="d-flex align-items-center">
        <div class="toggle-icon-wrapper">

            <button class="btn navbar-toggler-humburger-icon navbar-vertical-toggle" data-bs-toggle="tooltip"
                data-bs-placement="left" title="Toggle Navigation"><span class="navbar-toggle-icon"><span
                        class="toggle-line"></span></span></button>

        </div><a class="navbar-brand" href="<?php echo e(route('home')); ?>">
            <div class="d-flex align-items-center py-3"><img class="me-2"
                    src="<?php echo e(asset('assets/img/logo-blue.png')); ?>" alt="" width="150" />
            </div>
        </a>
    </div>
    <div class="collapse navbar-collapse" id="navbarVerticalCollapse">
        <div class="navbar-vertical-content scrollbar">
            <ul class="navbar-nav flex-column mb-3" id="navbarVerticalNav">

                <?php if(Auth::user()->hasRole('administrator|superadministrator')): ?>
                    <li class="nav-item">
                        <!-- label-->
                        <div class="row navbar-vertical-label-wrapper mt-3 mb-2">
                            <!-- users - roles - countries - settings -->
                            <div class="col-auto navbar-vertical-label"><?php echo e(__('Users & Roles')); ?>

                            </div>
                            <div class="col ps-0">
                                <hr class="mb-0 navbar-vertical-divider" />
                            </div>
                        </div>
                        <?php if(auth()->user()->hasPermission('users-read')): ?>
                            <!-- parent pages--><a class="nav-link <?php echo e(Route::is('users*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('users.index')); ?>" role="button" data-bs-toggle=""
                                aria-expanded="false">
                                <div class="d-flex align-items-center"><span class="nav-link-icon"><span
                                            class="fas fa-user"></span></span><span
                                        class="nav-link-text ps-1"><?php echo e(__('Users')); ?></span>
                                    <span
                                        class="badge badge-soft-primary m-1"><?php echo e(\app\models\User::all()->count() - 1); ?></span>
                                </div>
                            </a>
                        <?php endif; ?>

                        <?php if(auth()->user()->hasPermission('roles-read')): ?>
                            <!-- parent pages--><a class="nav-link <?php echo e(Route::is('roles*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('roles.index')); ?>" role="button" data-bs-toggle=""
                                aria-expanded="false">
                                <div class="d-flex align-items-center"><span class="nav-link-icon"><span
                                            class="fas fa-user-tag"></span></span><span
                                        class="nav-link-text ps-1"><?php echo e(__('Roles')); ?></span>
                                </div>
                            </a>
                        <?php endif; ?>

                        <?php if(auth()->user()->hasPermission('centrals-read')): ?>
                            <!-- parent pages-->
                            <a class="nav-link <?php echo e(Route::is('centrals*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('centrals.index')); ?>" role="button" data-bs-toggle=""
                                aria-expanded="false">

                                <div class="d-flex align-items-center">
                                    <span class="nav-link-icon">
                                        <span class="fas fa-user-tag">
                                        </span>
                                    </span>
                                    <span class="nav-link-text ps-1">
                                        <?php echo e(__('Centrals')); ?>

                                    </span>
                                    <span class="badge badge-soft-primary m-1">
                                        <?php echo e(getCentralsCount()); ?>

                                    </span>
                                </div>
                            </a>
                        <?php endif; ?>

                        <?php if(auth()->user()->hasPermission('compounds-read')): ?>
                            <!-- parent pages-->
                            <a class="nav-link <?php echo e(Route::is('compounds*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('compounds.index')); ?>" role="button" data-bs-toggle=""
                                aria-expanded="false">

                                <div class="d-flex align-items-center">
                                    <span class="nav-link-icon">
                                        <span class="fas fa-user-tag">
                                        </span>
                                    </span>
                                    <span class="nav-link-text ps-1">
                                        <?php echo e(__('Compounds')); ?>

                                    </span>

                                </div>
                            </a>
                        <?php endif; ?>

                        <?php if(auth()->user()->hasPermission('comments-read')): ?>
                            <!-- parent pages-->
                            <a class="nav-link <?php echo e(Route::is('comments*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('comments.index')); ?>" role="button" data-bs-toggle=""
                                aria-expanded="false">

                                <div class="d-flex align-items-center">
                                    <span class="nav-link-icon">
                                        <span class="fas fa-user-tag">
                                        </span>
                                    </span>
                                    <span class="nav-link-text ps-1">
                                        <?php echo e(__('Comments')); ?>

                                    </span>

                                </div>
                            </a>
                        <?php endif; ?>

                        <?php if(auth()->user()->hasPermission('tasks-read')): ?>
                            <!-- parent pages-->
                            <a class="nav-link <?php echo e(Route::is('tasks*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('tasks.index')); ?>" role="button" data-bs-toggle=""
                                aria-expanded="false">

                                <div class="d-flex align-items-center">
                                    <span class="nav-link-icon">
                                        <span class="fas fa-user-tag">
                                        </span>
                                    </span>
                                    <span class="nav-link-text ps-1">
                                        <?php echo e(__('tasks')); ?>

                                    </span>
                                    <span class="badge badge-soft-primary m-1">
                                        <?php echo e(getTasksCount()); ?>

                                    </span>

                                    <span class="badge badge-soft-success m-1">
                                        <?php echo e(getActiveTasksCount()); ?>

                                    </span>

                                    
                                </div>
                            </a>
                        <?php endif; ?>



                    </li>
                <?php endif; ?>



                <?php if(Auth::user()->hasRole('tech')): ?>
                    <li class="nav-item">
                        <!-- label-->
                        <div class="row navbar-vertical-label-wrapper mt-3 mb-2">
                            <!-- users - roles - countries - settings -->
                            <div class="col-auto navbar-vertical-label"><?php echo e(__('Tasks')); ?>

                            </div>
                            <div class="col ps-0">
                                <hr class="mb-0 navbar-vertical-divider" />
                            </div>
                        </div>
                        <!-- parent pages--><a class="nav-link <?php echo e(Route::is('tech.tasks*') ? 'active' : ''); ?>"
                            href="<?php echo e(route('tech.tasks')); ?>" role="button" data-bs-toggle="" aria-expanded="false">
                            <div class="d-flex align-items-center"><span class="nav-link-icon"><span
                                        class="fas fa-user"></span></span><span
                                    class="nav-link-text ps-1"><?php echo e(__('My Tasks')); ?></span>

                            </div>
                        </a>
                    </li>
                <?php endif; ?>

            </ul>

        </div>
    </div>
</nav>
<?php /**PATH D:\work\alaraby\resources\views/layouts/dashboard/_aside.blade.php ENDPATH**/ ?>