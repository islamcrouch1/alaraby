<?php $__env->startSection('adminContent'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\alaraby\resources\views/dashboard/home.blade.php ENDPATH**/ ?>