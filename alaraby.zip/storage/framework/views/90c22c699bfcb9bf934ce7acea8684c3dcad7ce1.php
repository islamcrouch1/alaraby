<?php $__env->startSection('adminContent'); ?>


    <form id="import" class="form_class m-3" style="display: inline-block" action="<?php echo e(route('tasks.import')); ?>" method="POST"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input class="form-control form-control-sm import-tasks" form="import" type="file" name="file"
            accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" data-buttonText="<?php echo e(__('Import')); ?>"
            required />
    </form>


    <div class="card mb-3" id="customersTable"
        data-list='{"valueNames":["name","email","phone","address","joined"],"page":10,"pagination":true}'>


        <form id="bulk-edit" method="POST" action="<?php echo e(route('tasks.bulk-action')); ?>">
            <?php echo csrf_field(); ?>

            <div class="card-header">
                <div class="row flex-between-center">
                    <div class="col-4 col-sm-auto d-flex align-items-center pe-0">
                        <h5 class="fs-0 mb-0 text-nowrap py-2 py-xl-0">
                            <?php if($tasks->count() > 0 && $tasks[0]->trashed()): ?>
                                <?php echo e(__('tasks trash')); ?>

                            <?php else: ?>
                                <?php echo e(__('tasks')); ?>

                            <?php endif; ?>
                        </h5>
                    </div>










                    <div class="col-8 col-sm-auto text-end ps-2">
                        <div class="d-none" id="table-customers-actions">
                            <div class="d-flex">


                                <input type="datetime-local" id="task_date" name="task_date" class="form-control"
                                    value="" required>

                                <select class="form-select form-select-sm" name="bulk_option" form="bulk-edit"
                                    aria-label="Bulk actions">
                                    <option value=""><?php echo e(__('Bulk actions')); ?></option>
                                    <option value="active"><?php echo e(__('Active')); ?></option>
                                    <option value="inactive"><?php echo e(__('not Active')); ?></option>
                                    <option value="paid"><?php echo e(__(' Paid')); ?></option>
                                    <option value="unpaid"><?php echo e(__('Non-Paid')); ?></option>
                                    <?php if($tasks->count() > 0 && $tasks[0]->trashed()): ?>
                                        <option value="delete"><?php echo e(__('delete')); ?></option>
                                    <?php else: ?>
                                        <option value="trash"><?php echo e(__('trash')); ?></option>
                                    <?php endif; ?>


                                </select>




                                <button form="bulk-edit" class="btn btn-falcon-default btn-sm ms-2"
                                    type="submit"><?php echo e(__('Apply')); ?></button>
                            </div>


                        </div>
                        <div id="table-customers-replace-element">
                            <a href="" data-bs-toggle="modal" data-bs-target="#filter-modal"
                                class="btn btn-falcon-default btn-sm"><span class="fas fa-filter"
                                    data-fa-transform="shrink-3 down-2"></span><span
                                    class="d-none d-sm-inline-block ms-1"><?php echo e(__('Filter')); ?></span></a>

                            <?php if(auth()->user()->hasPermission('tasks-create')): ?>
                                <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-falcon-default btn-sm"
                                    type="button"><span class="fas fa-plus"
                                        data-fa-transform="shrink-3 down-2"></span><span
                                        class="d-none d-sm-inline-block ms-1"><?php echo e(__('New')); ?></span></a>
                            <?php endif; ?>
                            <a href="<?php echo e(route('tasks.trashed')); ?>" class="btn btn-falcon-default btn-sm"
                                type="button"><span class="fas fa-trash" data-fa-transform="shrink-3 down-2"></span><span
                                    class="d-none d-sm-inline-block ms-1"><?php echo e(__('Trash')); ?></span></a>
                            <a href="<?php echo e(route('tasks.export', ['status' => request()->status, 'payment_status' => request()->payment_status, 'from' => request()->from, 'to' => request()->to, 'activation_from' => request()->activation_from, 'activation_to' => request()->activation_to])); ?>"
                                class="btn btn-falcon-default btn-sm" type="button"><span class="fas fa-external-link-alt"
                                    data-fa-transform="shrink-3 down-2"></span><span
                                    class="d-none d-sm-inline-block ms-1"><?php echo e(__('Export')); ?></span></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive scrollbar">
                    <?php if($tasks->count() > 0): ?>
                        <table class="table table-sm table-striped fs--1 mb-0 overflow-hidden">
                            <thead class="bg-200 text-900">
                                <tr>
                                    <th>
                                        <div class="form-check fs-0 mb-0 d-flex align-items-center">
                                            <input class="form-check-input" id="checkbox-bulk-customers-select"
                                                form="bulk-edit" type="checkbox"
                                                data-bulk-select='{"body":"table-customers-body","actions":"table-customers-actions","replacedElement":"table-customers-replace-element"}' />
                                        </div>
                                    </th>
                                    <th class="sort pe-1 align-middle white-space-nowrap" data-sort="name">
                                        <?php echo e(__('ID')); ?>

                                    </th>
                                    <th class="sort pe-1 align-middle white-space-nowrap" data-sort="name">
                                        <?php echo e(__('Client Name')); ?>

                                    </th>
                                    <th class="sort pe-1 align-middle white-space-nowrap" data-sort="name">
                                        <?php echo e(__('Clien Phone')); ?>

                                    </th>
                                    <th class="sort pe-1 align-middle white-space-nowrap" data-sort="name">
                                        <?php echo e(__('Service Number')); ?>

                                    </th>
                                    <th class="sort pe-1 align-middle white-space-nowrap" data-sort="name">
                                        <?php echo e(__('Technician Name')); ?>

                                    </th>
                                    <th class="sort pe-1 align-middle white-space-nowrap" data-sort="name">
                                        <?php echo e(__('central Name')); ?>

                                    </th>
                                    <th class="sort pe-1 align-middle white-space-nowrap" data-sort="name">
                                        <?php echo e(__('Status')); ?>

                                    </th>
                                    <th class="sort pe-1 align-middle white-space-nowrap" data-sort="name">
                                        <?php echo e(__('Task Date')); ?>

                                    </th>
                                    <th class="sort pe-1 align-middle white-space-nowrap" data-sort="name">
                                        <?php echo e(__('Task Activated Date')); ?>

                                    </th>

                                    <th class="sort pe-1 align-middle white-space-nowrap" style="min-width: 100px;"
                                        data-sort="joined"><?php echo e(__('Created at')); ?></th>
                                    <?php if($tasks->count() > 0 && $tasks[0]->trashed()): ?>
                                        <th class="sort pe-1 align-middle white-space-nowrap" style="min-width: 100px;"
                                            data-sort="joined"><?php echo e(__('Deleted at')); ?></th>
                                    <?php endif; ?>

                                    <th class="sort pe-1 align-middle white-space-nowrap" data-sort="tech_update">
                                        <?php echo e(__('Tech Update')); ?>

                                    </th>



                                    <th class="sort pe-1 align-middle white-space-nowrap" data-sort="action">
                                        <?php echo e(__('Action')); ?>

                                    </th>
                                </tr>
                            </thead>

                            <tbody class="list" id="table-customers-body">
                                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="btn-reveal-trigger">
                                        <td class="align-middle py-2" style="width: 28px;">
                                            <div class="form-check fs-0 mb-0 d-flex align-items-center">
                                                <input class="form-check-input" name="items[]"
                                                    value="<?php echo e($task->id); ?>" type="checkbox" id="customer-0"
                                                    data-bulk-select-row="data-bulk-select-row" />
                                            </div>
                                        </td>

                                        <td class="joined align-middle py-2"><?php echo e($task->id); ?> </td>
                                        <td class="joined align-middle py-2"><?php echo e($task->client_name); ?> </td>
                                        <td class="joined align-middle py-2"><?php echo e($task->client_phone); ?> </td>
                                        <td class="joined align-middle py-2"><?php echo e($task->service_number); ?> </td>
                                        <td class="joined align-middle py-2"><?php echo e($task->user->name); ?> </td>
                                        <td class="joined align-middle py-2"><?php echo e(getName($task->central)); ?> </td>
                                        <td class="joined align-middle py-2">
                                            <?php if($task->status == 'active'): ?>
                                                <span class="badge badge-soft-success "><?php echo e(__('active')); ?></span>
                                            <?php elseif($task->status == 'inactive' || $task->status == null): ?>
                                                <span class="badge badge-soft-danger "><?php echo e(__('inactive')); ?></span>
                                            <?php endif; ?>

                                            <?php if($task->payment_status == 1): ?>
                                                <span class="badge badge-soft-success "><?php echo e(__('paid')); ?></span>
                                            <?php elseif($task->payment_status == 2): ?>
                                                <span class="badge badge-soft-danger "><?php echo e(__('unpaid')); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="joined align-middle py-2"><?php echo e($task->task_date); ?> <br>
                                            <?php echo e(interval2($task->task_date)); ?> </td>

                                        <td class="joined align-middle py-2">
                                            <?php if(isset($task->activation_date)): ?>
                                                <?php echo e($task->activation_date); ?> <br>
                                                <?php echo e(interval2($task->activation_date)); ?>

                                            <?php endif; ?>
                                        </td>

                                        <td class="joined align-middle py-2"><?php echo e($task->created_at); ?> <br>
                                            <?php echo e(interval($task->created_at)); ?> </td>
                                        <?php if($task->trashed()): ?>
                                            <td class="joined align-middle py-2"><?php echo e($task->deleted_at); ?> <br>
                                                <?php echo e(interval($task->deleted_at)); ?> </td>
                                        <?php endif; ?>
                                        <td class="joined align-middle py-2">
                                            <?php if($task->cab != null): ?>
                                                <button class="btn btn-outline-success me-1 mb-1" type="button"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#show-task-<?php echo e($task->id); ?>"><?php echo e(__('show')); ?>

                                                </button>
                                            <?php endif; ?>
                                        </td>

                                        <td class="joined align-middle white-space-nowrap py-2">

                                            <div class="dropdown font-sans-serif position-static">
                                                <button class="btn btn-link text-600 btn-sm dropdown-toggle btn-reveal"
                                                    type="button" id="customer-dropdown-0" data-bs-toggle="dropdown"
                                                    data-boundary="window" aria-haspopup="true"
                                                    aria-expanded="false"><span
                                                        class="fas fa-ellipsis-h fs--1"></span></button>
                                                <div class="dropdown-menu dropdown-menu-end border py-0"
                                                    aria-labelledby="customer-dropdown-0">
                                                    <div class="bg-white py-2">
                                                        <?php if(
                                                            $task->trashed() &&
                                                                auth()->user()->hasPermission('tasks-restore')): ?>
                                                            <a class="dropdown-item"
                                                                href="<?php echo e(route('tasks.restore', ['task' => $task->id])); ?>"><?php echo e(__('Restore')); ?></a>
                                                        <?php elseif(auth()->user()->hasPermission('tasks-update')): ?>
                                                            <a class="dropdown-item"
                                                                href="<?php echo e(route('tasks.edit', ['task' => $task->id])); ?>"><?php echo e(__('Edit')); ?></a>
                                                        <?php endif; ?>

                                                        <?php if(auth()->user()->hasPermission('tasks-update') && $task->cab != null): ?>
                                                            <a class="dropdown-item"
                                                                href="<?php echo e(route('tech.edit', ['task' => $task->id])); ?>"><?php echo e(__('Edit tech update')); ?></a>
                                                        <?php endif; ?>
                                                        <?php if(auth()->user()->hasPermission('tasks-delete') ||
                                                                auth()->user()->hasPermission('tasks-trash')): ?>
                                                            <a href="<?php echo e(route('tasks.del', ['task' => $task->id])); ?>"
                                                                class="dropdown-item text-danger"><?php echo e($task->trashed() ? __('Delete') : __('Trash')); ?></a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>

                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="modal fade" id="show-task-<?php echo e($task->id); ?>" tabindex="-1" role="dialog"
                                aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document" style="max-width: 500px">
                                    <div class="modal-content position-relative">
                                        <div class="position-absolute top-0 end-0 mt-2 me-2 z-index-1">
                                            <button
                                                class="btn-close btn btn-sm btn-circle d-flex flex-center transition-base"
                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body p-0">
                                            <div class="rounded-top-lg py-3 ps-4 pe-6 bg-light">
                                                <h4 class="mb-1" id="modalExampleDemoLabel">
                                                    <?php echo e(__('task service number') . ': ' . $task->service_number); ?>

                                                </h4>
                                            </div>
                                            <div class="p-4 pb-0">

                                                <div class="table-responsive scrollbar">
                                                    <table class="table table-bordered overflow-hidden">
                                                        <colgroup>
                                                            <col class="bg-soft-primary" />
                                                            <col />
                                                        </colgroup>

                                                        <tbody>

                                                            <tr class="btn-reveal-trigger">
                                                                <td><?php echo e(__('db')); ?></td>
                                                                <td> <?php echo e($task->db); ?></td>
                                                            </tr>

                                                            <tr class="btn-reveal-trigger">
                                                                <td><?php echo e(__('box')); ?></td>
                                                                <td><?php echo e($task->box); ?></td>
                                                            </tr>

                                                            <tr class="btn-reveal-trigger">
                                                                <td><?php echo e(__('cab number')); ?></td>
                                                                <td><?php echo e($task->cab); ?></td>
                                                            </tr>

                                                            <tr class="btn-reveal-trigger">
                                                                <td><?php echo e(__('cable type')); ?></td>
                                                                <td><?php echo e($task->cable_type); ?></td>
                                                            </tr>

                                                            <tr class="btn-reveal-trigger">
                                                                <td><?php echo e(__('connectors')); ?></td>
                                                                <td><?php echo e($task->connectors); ?></td>
                                                            </tr>

                                                            <tr class="btn-reveal-trigger">
                                                                <td><?php echo e(__('face split')); ?></td>
                                                                <td><?php echo e($task->face_split); ?></td>
                                                            </tr>

                                                            <tr class="btn-reveal-trigger">
                                                                <td><?php echo e(__('cable length')); ?></td>
                                                                <td><?php echo e($task->cable_length); ?></td>
                                                            </tr>



                                                            <tr class="btn-reveal-trigger">
                                                                <td><?php echo e(__('comment')); ?></td>
                                                                <td><?php echo e(getName($task->comment)); ?></td>
                                                            </tr>


                                                        </tbody>
                                                    </table>
                                                </div>

                                                <div class="mb-3">
                                                    <div class="col-md-12" id="gallery">
                                                        <?php $__currentLoopData = $task->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <a target="_blank"
                                                                href="<?php echo e(asset('storage/images/tasks/' . $image->image)); ?>">
                                                                <img src="<?php echo e(asset('storage/images/tasks/' . $image->image)); ?>"
                                                                    style="width:100px; border: 1px solid #999"
                                                                    class="img-thumbnail img-prev"></a>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button class="btn btn-secondary" type="button"
                                                data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <h3 class="p-4"><?php echo e(__('No tasksTo Show')); ?></h3>
                    <?php endif; ?>
                </div>
            </div>

        </form>

        <div class="card-footer d-flex align-items-center justify-content-center">
            <?php echo e($tasks->appends(request()->query())->links()); ?>

        </div>

    </div>


    <!-- start filter modal -->
    <div class="modal fade" id="filter-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document" style="max-width: 60%">
            <div class="modal-content position-relative">
                <div class="position-absolute top-0 end-0 mt-2 me-2 z-index-1">
                    <button class="btn-close btn btn-sm btn-circle d-flex flex-center transition-base"
                        data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="">
                    <div class="modal-body p-0">
                        <div class="rounded-top-lg py-3 ps-4 pe-6 bg-light">
                            <h4 class="mb-1" id="modalExampleDemoLabel">
                                <?php echo e(__('search filters')); ?></h4>
                        </div>
                        <div class="p-4 pb-0">

                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <input class="form-control search-input fuzzy-search" type="search"
                                        value="<?php echo e(request()->search); ?>" name="search" autofocus
                                        placeholder="<?php echo e(__('Search...')); ?>" />
                                </div>


                                <div class="col-md-12 mb-1">
                                    <label for=""><?php echo e(__('task date')); ?></label>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <div class="input-group"><span class="input-group-text"
                                            id="from"><?php echo e(__('From')); ?></span>
                                        <input type="date" id="from" name="from" class="form-control"
                                            value="<?php echo e(request()->from); ?>">
                                    </div>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <div class="input-group"><span class="input-group-text"
                                            id="to"><?php echo e(__('To')); ?></span>
                                        <input type="date" id="to" name="to" class="form-control"
                                            value="<?php echo e(request()->to); ?>">
                                    </div>
                                </div>

                                <div class="col-md-12 mb-1">
                                    <label for=""><?php echo e(__('activation date')); ?></label>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <div class="input-group"><span class="input-group-text"
                                            id="from"><?php echo e(__('From')); ?></span>
                                        <input type="date" id="from" name="activation_from" class="form-control"
                                            value="<?php echo e(request()->activation_from); ?>">
                                    </div>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <div class="input-group"><span class="input-group-text"
                                            id="to"><?php echo e(__('To')); ?></span>
                                        <input type="date" id="to" name="activation_to" class="form-control"
                                            value="<?php echo e(request()->activation_to); ?>">
                                    </div>
                                </div>


                                <div class="col-md-3 mb-3">
                                    <select name="status" class="form-select">
                                        <option value=""><?php echo e(__('All Status')); ?></option>
                                        <option value="active" <?php echo e(request()->status == 'active' ? 'selected' : ''); ?>>
                                            <?php echo e(__('active')); ?></option>
                                        <option value="inactive" <?php echo e(request()->status == 'inactive' ? 'selected' : ''); ?>>
                                            <?php echo e(__('inactive')); ?></option>

                                    </select>
                                </div>

                                <div class="col-md-3 mb-3">
                                    <select name="payment_status" class="form-select">
                                        <option value=""><?php echo e(__('payment status')); ?></option>
                                        <option value="1" <?php echo e(request()->payment_status == '1' ? 'selected' : ''); ?>>
                                            <?php echo e(__('paid')); ?></option>
                                        <option value="2" <?php echo e(request()->payment_status == '2' ? 'selected' : ''); ?>>
                                            <?php echo e(__('unpaid')); ?></option>

                                    </select>
                                </div>


                                <div class="col-md-3 mb-3">
                                    <select class="form-select" name="central_id">
                                        <option value=""><?php echo e(__('select central')); ?></option>

                                        <?php $__currentLoopData = $centrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $central): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($central->id); ?>"
                                                <?php echo e(request()->central_id == $central->id ? 'selected' : ''); ?>>
                                                <?php echo e(app()->getLocale() == 'ar' ? $central->name_ar : $central->name_en); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>


                                <div class="col-md-3 mb-3">
                                    <select class="form-select" name="comment_id">
                                        <option value=""><?php echo e(__('select comment')); ?></option>

                                        <?php $__currentLoopData = $commmnets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($comment->id); ?>"
                                                <?php echo e(request()->comment_id == $comment->id ? 'selected' : ''); ?>>
                                                <?php echo e(app()->getLocale() == 'ar' ? $comment->name_ar : $comment->name_en); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>


                                <div class="col-md-3 mb-3">
                                    <select class="form-select" name="compound_id">
                                        <option value=""><?php echo e(__('select compound')); ?></option>

                                        <?php $__currentLoopData = $compounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compound): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($compound->id); ?>"
                                                <?php echo e(request()->compound_id == $compound->id ? 'selected' : ''); ?>>
                                                <?php echo e(app()->getLocale() == 'ar' ? $compound->name_ar : $compound->name_en); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>




                            </div>

                        </div>

                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button"
                            data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                        <button class="btn btn-primary" type="submit"><?php echo e(__('Apply')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- end filter modal -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\alaraby\resources\views/dashboard/tasks/index.blade.php ENDPATH**/ ?>