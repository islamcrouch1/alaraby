<?php if(session()->has('success')): ?>
    <div class="alert alert-success border-2 d-flex align-items-center" role="alert">
        <div class="bg-success me-3 icon-item"><span class="fas fa-check-circle text-white fs-3"></span></div>
        <p class="mb-0 flex-1"><?php echo e(session()->get('success')); ?></p>
        <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>

    <?php
        session()->forget('success');
    ?>
<?php endif; ?>
<?php if(session()->has('error')): ?>
    <div class="alert alert-danger border-2 d-flex align-items-center" role="alert">
        <div class="bg-danger me-3 icon-item"><span class="fas fa-times-circle text-white fs-3"></span></div>
        <p class="mb-0 flex-1"><?php echo e(session()->get('error')); ?></p>
        <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>

    <?php
        session()->forget('error');
    ?>
<?php endif; ?>
<?php if(session()->has('failures')): ?>
    <table class="table table-danger">
        <tr>
            <th>Row</th>
            <th>Attribute</th>
            <th>Errors</th>
            <th>Value</th>
        </tr>

        <?php $__currentLoopData = session()->get('failures'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $validation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($validation->row()); ?></td>
                <td><?php echo e($validation->attribute()); ?></td>
                <td>
                    <ul>
                        <?php $__currentLoopData = $validation->errors(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($e); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </td>
                <td>
                    <?php echo e(isset($validation->values()[$validation->attribute()]) ? $validation->values()[$validation->attribute()] : 'No Data'); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php
        session()->forget('failures');
    ?>

<?php endif; ?>
<?php /**PATH D:\work\alaraby\resources\views/layouts/dashboard/_flash.blade.php ENDPATH**/ ?>